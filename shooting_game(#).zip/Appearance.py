#몹 출현 메커니즘
import pygame

class Appearance:

